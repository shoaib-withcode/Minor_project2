# Hospital Management System — Web Edition

This is a browser-based edition of the supplied Java Swing + MySQL Hospital Management System. It keeps the original pale-blue/white visual palette and implements the same core workflows with HTML, CSS, JavaScript, Java Spring Boot and MySQL.

## Features
- Login with Admin, Receptionist and Viewer roles
- Add and view patients
- View doctors
- Book appointments (one appointment per doctor per date; past dates blocked)
- View appointment schedule and patient history
- Admin-only patient removal
- Responsive browser interface

## Local setup
1. Install JDK 17+ and Maven, and start MySQL.
2. Run `database/schema.sql` in MySQL Workbench. It creates the `hospital` database and demo accounts/doctors. Existing data is not dropped.
3. From this project folder, set your database variables and run the app:

```powershell
$env:HMS_DB_URL="jdbc:mysql://localhost:3306/hospital"
$env:HMS_DB_USER="root"
$env:HMS_DB_PASSWORD="YOUR_MYSQL_PASSWORD"
mvn spring-boot:run
```

4. Open http://localhost:8080

Demo accounts:
- Admin: `admin` / `admin123`
- Receptionist: `reception` / `reception123`
- Viewer: `viewer` / `viewer123`

## Deploy on Render (single web service)
This repository includes a Dockerfile. Create a Render **Web Service** from the GitHub repository and select **Docker** as the runtime. Add these environment variables in Render:

- `HMS_DB_URL` = JDBC URL of a reachable MySQL database, for example `jdbc:mysql://HOST:3306/hospital?useSSL=true&allowPublicKeyRetrieval=true`
- `HMS_DB_USER` = database username
- `HMS_DB_PASSWORD` = database password

Create the database and run `database/schema.sql` against it before opening the deployed site. Render's local filesystem is not a managed MySQL database; use a separate hosted MySQL provider and allow the Render service to connect to it. Render assigns `PORT` automatically; the app reads it.

## Important
- The original Swing source is not used by the web runtime; the supplied project is retained as the basis for the feature set and database schema.
- This is a college demonstration project, not suitable for real patient records without a security review, stronger password hashing, HTTPS, audit logging, backups and privacy controls.
- Demo passwords are included for classroom testing only. Change them before any public deployment.
