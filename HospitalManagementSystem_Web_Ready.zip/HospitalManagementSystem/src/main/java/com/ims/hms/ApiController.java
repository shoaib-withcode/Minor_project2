package com.ims.hms;

import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/api")
public class ApiController {
    private final JdbcTemplate db;
    public ApiController(JdbcTemplate db) { this.db = db; }

    private Map<String,Object> ok(String message) { return Map.of("message", message); }
    private String role(HttpSession s) { Object r=s.getAttribute("role"); if(r==null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Please log in"); return r.toString(); }
    private void writeAccess(HttpSession s) { String r=role(s); if(!r.equals("admin")&&!r.equals("reception")) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"You do not have permission for this action"); }

    @PostMapping("/login") public Map<String,Object> login(@RequestBody Map<String,String> body, HttpSession session) {
        String username=body.getOrDefault("username","").trim(), password=body.getOrDefault("password","");
        List<Map<String,Object>> rows=db.queryForList("SELECT role FROM users WHERE username=? AND password_hash=SHA2(?,256)",username,password);
        if(rows.isEmpty()) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Invalid username or password");
        String r=rows.get(0).get("role").toString(); session.setAttribute("username",username); session.setAttribute("role",r);
        return Map.of("username",username,"role",r);
    }
    @GetMapping("/me") public Map<String,Object> me(HttpSession s) { return Map.of("username",s.getAttribute("username")==null?"":s.getAttribute("username"),"role",role(s)); }
    @PostMapping("/logout") public Map<String,Object> logout(HttpSession s) { s.invalidate(); return ok("Logged out"); }

    @GetMapping("/patients") public List<Map<String,Object>> patients(HttpSession s) { role(s); return db.queryForList("SELECT id,name,age,gender FROM patients ORDER BY id DESC"); }
    @PostMapping("/patients") public Map<String,Object> addPatient(@RequestBody Map<String,Object> b,HttpSession s) {
        writeAccess(s); String name=Objects.toString(b.get("name"),"").trim(); int age;
        try { age=Integer.parseInt(Objects.toString(b.get("age"),"")); } catch(Exception e){ throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Enter a valid age"); }
        String gender=Objects.toString(b.get("gender"),""); if(name.isEmpty()||age<0||age>120) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Enter a name and age from 0 to 120");
        db.update("INSERT INTO patients(name,age,gender) VALUES(?,?,?)",name,age,gender); return ok("Patient registered successfully");
    }
    @DeleteMapping("/patients/{id}") public Map<String,Object> deletePatient(@PathVariable int id,HttpSession s) {
        if(!role(s).equals("admin")) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"Only Admin can remove patients");
        db.update("DELETE FROM appointments WHERE patient_id=?",id); int n=db.update("DELETE FROM patients WHERE id=?",id); if(n==0) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Patient ID not found"); return ok("Patient and linked appointments removed");
    }
    @GetMapping("/doctors") public List<Map<String,Object>> doctors(HttpSession s) { role(s); return db.queryForList("SELECT id,name,specialization FROM doctors ORDER BY id"); }
    @GetMapping("/appointments") public List<Map<String,Object>> appointments(HttpSession s) { role(s); return db.queryForList("SELECT a.id,p.name patient,d.name doctor,d.specialization,a.appointment_date date FROM appointments a JOIN patients p ON p.id=a.patient_id JOIN doctors d ON d.id=a.doctor_id ORDER BY a.appointment_date"); }
    @PostMapping("/appointments") public Map<String,Object> book(@RequestBody Map<String,String> b,HttpSession s) {
        writeAccess(s); try { int pid=Integer.parseInt(b.get("patientId")), did=Integer.parseInt(b.get("doctorId")); LocalDate date=LocalDate.parse(b.get("date"));
            if(date.isBefore(LocalDate.now())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Past dates are not allowed");
            if(db.queryForObject("SELECT COUNT(*) FROM patients WHERE id=?",Integer.class,pid)==0 || db.queryForObject("SELECT COUNT(*) FROM doctors WHERE id=?",Integer.class,did)==0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Patient ID or Doctor ID does not exist");
            db.update("INSERT INTO appointments(patient_id,doctor_id,appointment_date) VALUES(?,?,?)",pid,did,Date.valueOf(date)); return ok("Appointment booked successfully");
        } catch(ResponseStatusException e){throw e;} catch(org.springframework.dao.DuplicateKeyException e){throw new ResponseStatusException(HttpStatus.CONFLICT,"This doctor already has an appointment on that date");} catch(Exception e){throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Enter valid patient ID, doctor ID and date (YYYY-MM-DD)");}
    }
    @GetMapping("/patients/{id}/history") public List<Map<String,Object>> history(@PathVariable int id,HttpSession s) { role(s); return db.queryForList("SELECT a.id,p.name patient,d.name doctor,d.specialization,a.appointment_date date FROM appointments a JOIN patients p ON p.id=a.patient_id JOIN doctors d ON d.id=a.doctor_id WHERE p.id=? ORDER BY a.appointment_date",id); }
}
